<?php

namespace App\Controller;

use App\Entity\Genre;
use App\Entity\Serie;
use App\Entity\Episode;
use App\Repository\EpisodeRepository;
use App\Repository\GenreRepository;
use App\Repository\SerieRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class SerieController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function home(GenreRepository $genreRepository): Response
    {
        $genres = $genreRepository->findAll();
        return $this->render('serie/index.html.twig', [
            'genres' => $genres,
        ]);
    }

    #[Route('/details/{id}', name: 'app_detail')]
    public function details(Genre $genre, SerieRepository $serieRepository): Response
    {
        $genreName = $genre->getName();
        $series = $serieRepository->findBy(['genre' => $genre]);
        return $this->render('serie/details.html.twig', [
            'series' => $series,
            'name' => $genreName

        ]);
    }

    #[Route('/episode/{id}', name: 'app_episode')]
    public function episode(Serie $serie, EpisodeRepository $episodeRepository): Response
    {

        $episode = $episodeRepository->findBy(['serie' => $serie]);
        return $this->render('serie/episode.html.twig', [
            'episode' => $episode,
        ]);
    }

}






